// Sample solution (delete from autograder)

function setup() {
    createCanvas(300, 300);
}

function draw() {
    background(255);
    fill(255);
    circle(width / 2, height / 2, 50);
}

function testMe() {
    return 1;
    let a = 1;
}