// Sample solution (delete from autograder)

function setup() {
    createCanvas(400, 400);
}

function draw() {

}