// Sample solution (delete from autograder)

function setup() {
    createCanvas(400, 400);
}

function draw() {
    background(0);
    fill(255, 0, 0);
    square(width / 2, height / 2, 50);
}